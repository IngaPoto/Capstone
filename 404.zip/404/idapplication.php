<?php
	$firstname = $_POST['firstname'];
	$secondname = $_POST['secondname'];
	$lastname = $_POST['lastname'];
	$maidenname = $_POST['maidenname'];
	$gender = $_POST['gender'];
	$citizen = $_POST['citizen'];
	$idnumber = $_POST['idnumber'];
	$dateofbirth = $_POST['dateofbirth'];
	$cellphone = $_POST['cellphone'];
	$day= $_POST['day'];
	$month = $_POST['month'];
	
	

	// Database connection
	$conn = new mysqli('localhost','root','','project');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into idapplication(firstname, secondname, lastname
			, maidenname, gender, citizen, idnumber, dateofbirth,  cellphone, day, month ) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
		$stmt->bind_param("ssssssiiiis", $firstname, $secondname, $lastname, $maidenname, $gender, $citizen, $idnumber, $dateofbirth, $cellphone, $day,$month);
		$execval = $stmt->execute();
		echo $execval;
		header("location:upload.html");
		$stmt->close();
		$conn->close();
	}
?>