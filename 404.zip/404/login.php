<?php
    $idnumber = $_POST['idnumber'];
    $password = $_POST['password'];

    // Database connection
	$conn = new mysqli('localhost','root','','project');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
		} else {
		$stmt = $conn->prepare("select * from register where idnumber =?");
		$stmt->bind_param("s",$idnumber);
		$stmt->execute();
		$stmt_result = $stmt->get_result();
		 if ($stmt_result->num_rows > 0) {
		     $data = $stmt_result->fetch_assoc();
		     if($data['password'] === $password){
		     	header("location:application selection.html");
		     } else {
		     	echo "<h2>Invalid email or password</h2>";
		     }	
		 } else {
		 	echo "<h2>Invalid email or password</h2>";
		 }

		}

?>