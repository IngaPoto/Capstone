<?php
	$title = $_POST['title'];
	$forenames = $_POST['forenames'];
	$idnumber = $_POST['idnumber'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$cellphone = $_POST['cellphone'];
	
	

	// Database connection
	$conn = new mysqli('localhost','root','','project');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into register(title, forenames, idnumber, email,password, cellphone) values(?, ?, ?, ?, ?, ?)");
		$stmt->bind_param("sssssi", $title, $forenames, $idnumber, $email, $password, $cellphone,);
		$execval = $stmt->execute();
		echo $execval;
		header("location:login.html");
		$stmt->close();
		$conn->close();
	}
?>